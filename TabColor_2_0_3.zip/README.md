# TabColor

TabColor :: Add-ons for Firefox
https://addons.mozilla.org/ja/firefox/addon/tabcolor/

指定したキーワードにマッチしたURLの場合、ブラウザタブ全体が赤く表示されます。  
複数のキーワードを登録することができます。

If the URL matches the specified keyword, the entire browser tab is displayed in red.
Multiple keywords can be registered.

<img src="https://raw.githubusercontent.com/takedajs/ImageStorage/master/images/%E3%82%BF%E3%83%95%E3%82%99%E3%82%92%E8%B5%A4%E3%81%8F%E3%81%97%E3%81%A6%E3%81%84%E3%82%8B.png" alt="タブを赤くする" title="タブを赤くする">

<img src="https://raw.githubusercontent.com/takedajs/ImageStorage/master/images/tabColor_%E3%82%AD%E3%83%BC%E3%83%AF%E3%83%BC%E3%83%88%E3%82%99%E7%99%BB%E9%8C%B2.png" alt="キーワード登録" title="キーワード登録">
